import xbmcgui
from cloudshare.plugin_utils import *

from cloudshare.common.storage import VideoDatabase
from cloudshare.common.entity import Video

###################################
#### Plugin View Configuration ####
###################################
class Root(View):
    def __init__(self, params = {}):
        View.__init__(self, params)
        
    def execute(self):
        DirectoryItemUtility.addDirectoryFolder("Video")
        DirectoryItemUtility.addDirectoryFolder("Television")
        DirectoryItemUtility.addDirectoryFolder("Music")
        DirectoryItemUtility.endDirectory()
    pass #END Root
ViewRegistry.register(Root, "")

class StreamingVideoPlayer(View):
    __alt_name__ = "video_player"
    def __init__(self, params = {}):
        View.__init__(self, params)
    
    @classmethod
    def convert_video_to_playable(cls, video, params = {}):
        params['name'] = video.name
        params['source'] = "http://%s:%s%s" % (video.server.ip_address, video.server.port, video.stream)
        DirectoryItemUtility.addDirectoryItem(cls.__alt_name__, video.name, params)
    
    def execute(self):
        print "Attempting to play movie with: " + repr(self._params)
        StreamingMoviePlayer().play(self._params['source'], xbmcgui.ListItem(self._params['name']))
#END StreamingVideoPlayer    

class VideoView(View):
    __alt_name__ = "Video"
    def __init__(self, params = {}):
        View.__init__(self, params)
        
    def execute(self):
        with VideoDatabase as db:
            for video in Video.select_all(db):
                StreamingVideoPlayer.convert_video_to_playable(video)        
        DirectoryItemUtility.endDirectory()
#END Video

class TelevisionView(View):
    __alt_name__ = "Television"
    def __init__(self, params = {}):
        View.__init__(self, params)
        
    def execute(self):
        DirectoryItemUtility.endDirectory()
#END Television

class MusicView(View):
    __alt_name__ = "Music"
    def __init__(self, params = {}):
        View.__init__(self, params)
        
    def execute(self):
        DirectoryItemUtility.endDirectory()
#END Music

###################################
## End Plugin View Configuration ##
###################################

class CloudClientWrapper:
    @classmethod
    def start(cls):
        ViewRegistry.execute()
        