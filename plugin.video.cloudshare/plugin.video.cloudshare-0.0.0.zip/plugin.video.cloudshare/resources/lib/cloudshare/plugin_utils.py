import xbmc, xbmcaddon, xbmcplugin, xbmcgui
import sys,os,time,threading

import urllib
from urlparse import urlparse
from cgi import parse_qs

addon_id = sys.argv[0][9:-1]
__addon__ = xbmcaddon.Addon(id=addon_id)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')

class UriUtilitiy:
    pluginBaseUrl = sys.argv[0][:-1]
    url = urlparse(sys.argv[2] if sys.argv[2] else "")
    
    @classmethod
    def build(cls, params):
        temp = cls.pluginBaseUrl + '?' + urllib.urlencode(params)
        print temp
        return temp
        
    @classmethod
    def params(cls):
        try:
            return cls.__params
        except AttributeError: 
            params = parse_qs(cls.url.query)
            for key in params:
                if type(params[key]) is list and len(params[key]) == 1:
                    params[key] = params[key][0]
                
            cls.__params = params 
            return cls.__params
        
class DirectoryItemUtility:
    handle = int(sys.argv[1])
    
    @classmethod
    def addDirectoryFolder(cls, view, name = None, params = {}):
        params['view'] = view
        name = name if name else view
        xbmcplugin.addDirectoryItem(handle=cls.handle, url=UriUtilitiy.build(params), listitem=xbmcgui.ListItem(name), isFolder=True)
    
    @classmethod
    def addDirectoryItem(cls, view, name, params = {}):
        params['view'] = view
        xbmcplugin.addDirectoryItem(handle=cls.handle, url=UriUtilitiy.build(params), listitem=xbmcgui.ListItem(name), isFolder=False)
        
    @classmethod
    def endDirectory(cls):
        xbmcplugin.endOfDirectory(handle=cls.handle)

#############################################################
########## DYNAMIC VIEW REGISTRATION AND LOOKUP #############
#############################################################
class ViewRegistry(type):
    views = {}
    def __new__(cls, name, bases, attrs):
        newtype = super(ViewRegistry, cls).__new__(cls, name, bases, attrs)
        cls.views[name] = newtype
        try:
            alt_name = newtype.__alt_name__
            cls.views[alt_name] = newtype
        except:
            print "%s did not define an alternate name" % (name)
        return newtype

    @classmethod
    def register(cls, type, name):
        cls.views[name] = type

    @classmethod
    def view(cls, name):
        try:
            return cls.views[name]
        except KeyError:
            print "Unable to lookup view: " + repr(name)
            return View
    
    @classmethod
    def execute(cls):
        params = UriUtilitiy.params()
        view = cls.view(params.get('view', ''))
        try:
            view(params).execute()
        except NotImplementedError:
            print "Unable to execute plugin for view: " + repr(view)

# arbitrary base class for every class that should be in the ViewRegistry
class View(object):
    __metaclass__ = ViewRegistry
    
    def __init__(self, params = {}):
        self._params = params
    
    def execute(self):
        raise NotImplementedError("Please Implement this method")

#############################################################
######## END DYNAMIC VIEW REGISTRATION AND LOOKUP ###########
#############################################################


#############################################################
################# STREAMING MOVIE PLAYER ####################
#############################################################
class StreamingMoviePlayer(xbmc.Player):
     def __init__ (self, last_part=False):
        self.dialog = None
        self.last_part = last_part
        xbmc.Player.__init__(self)
        print 'Initializing StreamingMoviePlayer...'
        
     def play(self, url, listitem):
        print 'Now im playing... %s' % url
        xbmc.Player(xbmc.PLAYER_CORE_AUTO).play(url, listitem)            
        
     def isplaying(self):
        xbmc.Player.isPlaying(self)

     def onPlayBackEnded(self):
        global currentTime
        global totalTime
        global finalPart
        if finalPart:
            percentWatched = currentTime / totalTime
            print 'current time: ' + str(currentTime) + ' total time: ' + str(totalTime) + ' percent watched: ' + str(percentWatched)
            #if percentWatched >= watched_percent:
                #set watched
                #vidname=cache.get('videoname')
                #video = get_video_name(vidname)
                #print 'Auto-Watch - Setting %s to watched' % video
                #ChangeWatched(imdbnum, video_type, video['name'], season_num, episode_num, video['year'], watched=7)

     def onPlayBackStopped(self):
        global currentTime
        global totalTime
        global finalPart
        if finalPart:
            percentWatched = currentTime / totalTime
            print 'current time: ' + str(currentTime) + ' total time: ' + str(totalTime) + ' percent watched: ' + str(percentWatched)
            #if percentWatched >= watched_percent and totalTime > 1:
                #set watched
                #vidname=cache.get('videoname')
                #video = get_video_name(vidname)
                #print 'Auto-Watch - Setting %s to watched' % video            
                #ChangeWatched(imdbnum, video_type, video['name'], season_num, episode_num, video['year'], watched=7)
                
#############################################################
############### END STREAMING MOVIE PLAYER ##################
#############################################################