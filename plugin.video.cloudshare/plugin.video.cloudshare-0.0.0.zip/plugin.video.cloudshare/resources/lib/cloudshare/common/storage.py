import xbmc, xbmcvfs
import os, threading



class CoreDatabase(type):    
    def __new__(cls, name, bases, attrs):
        newtype = super(CoreDatabase, cls).__new__(cls, name, bases, attrs)
        
        #Need a thread local to handle SQLite connections across threads
        newtype.__threadlocal = threading.local()   
                
        def __connect__(clz):
            return getattr(clz.__threadlocal, 'conn', None)
        
        def connect(clz):
            conn = clz.__connect__()
            if conn is None:
                conn = cls.__sql().connect(clz.databasePath())
                setattr(clz.__threadlocal, 'conn', conn)
                setattr(clz.__threadlocal, 'cache', { })
            return conn
        
        def cur(clz):
            cursor = getattr(clz.__threadlocal, 'cursor', None)
            if cursor is None:
                cursor = clz.connect().cursor()
                setattr(clz.__threadlocal, 'cursor', cursor)
            return cursor
        
        def commit(clz):
            clz.connect().commit()
            setattr(clz.__threadlocal, 'cursor', None)
        
        def execute(clz, sql, params = None, callback = lambda cur: cur):
            ## TODO ## This is not high performant....
            key = sql + repr(params)
            try:
                cached = getattr(clz.__threadlocal, 'cache')[key]
                print "Returning cached result: " + repr(cached)
                return cached
            except:
                try:
                    cursor = clz.cur()
                    if params:
                        cursor.execute(sql, params)
                    else:
                        cursor.execute(sql)
                    res = callback(cursor)
                    if res != cursor:
                        getattr(clz.__threadlocal, 'cache')[key] = res
                    return res
                except Exception, e:
                    print "Attempted to execute: " + repr(sql) + " resulted in error: " + repr(e) 
                    raise e
                
        def executemany(clz, sql, many):
            try:
                cursor = clz.cur()
                cursor.executemany(sql, many)
                return cursor
            except Exception, e:
                print "Attempted to executemany: " + repr(sql) + " " + repr(many) + " resulted in error: " + repr(e) 
                raise e
                
        def rollback(clz):
            clz.connect().rollback()
                
        def close(clz):
            try:
                clz.connect().close()
            except Exception, e:
                print "Attempt to close DB connection resulted in error: " + repr(e) 
                raise e
            finally:
                setattr(clz.__threadlocal, 'conn', None)
                setattr(clz.__threadlocal, 'cursor', None)
                setattr(clz.__threadlocal, 'cache', None)
        
        def __enter__(clz):
            clz.connect()
            return clz
        
        def __exit__(clz, type, value, traceback):
            con = clz.__connect__()
            if con:
                try:
                    con.commit()
                except Exception, e:
                    print "Could not commit: " + repr(e)
                    con.rollback()
                finally:
                    clz.close()
                    
        def create_table(clz, table):
            tableState = os.path.join(clz.databaseState(), table.__name__)
            if not os.path.exists(tableState):
                with clz as db:
                    table.drop_table(db)
                    table.create_table(db)
                    open(tableState, 'w').close()
        
        import types
        newtype.__connect__ = types.MethodType(__connect__, newtype)
        newtype.connect = types.MethodType(connect, newtype) 
        newtype.cur = types.MethodType(cur, newtype) 
        newtype.commit = types.MethodType(commit, newtype) 
        newtype.rollback = types.MethodType(rollback, newtype) 
        newtype.execute = types.MethodType(execute, newtype) 
        newtype.executemany = types.MethodType(executemany, newtype) 
        newtype.close = types.MethodType(close, newtype) 
        newtype.create_table = types.MethodType(create_table, newtype) 
        newtype.__enter__ = types.MethodType(__enter__, newtype)
        newtype.__exit__ = types.MethodType(__exit__, newtype) 
        
        return newtype
    
    @classmethod
    def __sql(cls):
        try: 
            return cls.sql
        except:
            try: 
                import sqlite3 as database
                common.addon.log('CloudShareDB - Using sqlite3 as DB engine version: %s' % database.sqlite_version, 2)
            except Exception, e: 
                print "Could not import sqlite3: " + repr(e)
                try:
                    from pysqlite2 import dbapi2 as database
                    common.addon.log('CloudShareDB - Using pysqlite2 as DB engine', 2)
                except Exception, ee:
                    "Could not import pysqlite2: " + repr(ee)
            
            cls.sql = database
            return cls.sql

class VideoDatabase(object):
    __metaclass__ = CoreDatabase
    
    @classmethod
    def databaseState(cls):
        path = xbmc.translatePath('special://profile/addon_data/script.module.cloudshare.common/database/video')
        try:
            if not xbmcvfs.exists(path): xbmcvfs.mkdirs(path)
        except:
            if not os.path.exists(path): os.makedirs(path)  
        return path
    
    @classmethod
    def databasePath(cls):
        path = xbmc.translatePath('special://profile/addon_data/script.module.cloudshare.common/database')
        try:
            if not xbmcvfs.exists(path): xbmcvfs.mkdirs(path)
        except:
            if not os.path.exists(path): os.makedirs(path)  
        return os.path.join(path, 'video.db')
        
            
            
                
     