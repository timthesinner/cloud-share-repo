import xbmcaddon
import sys,os,py_compile,time

__addon__ = xbmcaddon.Addon(id= sys.argv[0][9:-1])

def recurse_walk(root):
    for root, subs, files in os.walk(root):
        for f in files:
            fullpath = os.path.join(root, f)
            if fullpath.endswith('.py') and not os.path.exists(fullpath[:-2] + 'pyc') and not os.path.exists(fullpath[:-2] + 'pyo') and not f.startswith('default'):
                py_compile.compile(fullpath)
                if os.path.exists(fullpath[:-2] + 'pyc') or os.path.exists(fullpath[:-2] + 'pyo'):
                    os.remove(fullpath)
        for s in subs:
            recurse_walk(os.path.join(root, s))
recurse_walk(os.path.join(__addon__.getAddonInfo('path')))

for root, _, files in os.walk(os.path.join(__addon__.getAddonInfo('path'))):
    for f in files:
        fullpath = os.path.join(root, f)
        if f.startswith('default_slim'):
            os.remove(os.path.join(root, 'default.py'))
            os.rename(fullpath, os.path.join(root, 'default.py'))

sys.path.insert(0, os.path.join(__addon__.getAddonInfo('path'), 'resources', 'lib'))
from cloudshare.coreclient import CloudClientWrapper
CloudClientWrapper.start()