import xbmcaddon
import sys,os

__addon__ = xbmcaddon.Addon(id= sys.argv[0][9:-1])

sys.path.insert(0, os.path.join(__addon__.getAddonInfo('path'), 'resources', 'lib'))
from cloudshare.coreclient import CloudClientWrapper
CloudClientWrapper.start()
