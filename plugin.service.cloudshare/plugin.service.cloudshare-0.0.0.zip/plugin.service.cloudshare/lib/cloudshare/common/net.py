import urllib, urllib2
import gzip, re, StringIO

class RestClient:
    def __init__(self, user_agent='Mozilla/5.0 Ubuntu/8.10 Firefox/3.0.4'):
        self.user_agent = user_agent
        
    def fetch(self, url, form_data={}, headers={}, compression=False):
        encoding = ''
        req = urllib2.Request(url)
        if form_data:
            form_data = urllib.urlencode(form_data)
            req = urllib2.Request(url, form_data)
            
        req.add_header('User-Agent', self.user_agent)
        for k, v in headers.items():
            req.add_header(k, v)
        if compression:
            req.add_header('Accept-Encoding', 'gzip')
            
        try:
            response = urllib2.urlopen(req, None, 10)
            return HttpResponse(response)
        except Exception, e:
            print "Error: " + repr(e)

class HttpResponse:
    content = ''    
    def __init__(self, response):
        self._response = response
        html = response.read()
        try:
            if response.headers['content-encoding'].lower() == 'gzip':
                html = gzip.GzipFile(fileobj=StringIO.StringIO(html)).read()
        except:
            pass
        
        try:
            content_type = response.headers['content-type']
            if 'charset=' in content_type:
                encoding = content_type.split('charset=')[-1]
        except:
            pass

        r = re.search('<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"', html, re.IGNORECASE)
        if r:
            encoding = r.group(1) 
                   
        try:
            html = unicode(html, encoding)
        except:
            pass
            
        self.content = html    
    def __str__(self):
        return self.content
    def __repr__(self):
        return "HttpResponse[content={0}]".format(self.__str__())
    def headers(self):
        return self._response.info().headers        
    def url(self):
        return self._response.geturl()
