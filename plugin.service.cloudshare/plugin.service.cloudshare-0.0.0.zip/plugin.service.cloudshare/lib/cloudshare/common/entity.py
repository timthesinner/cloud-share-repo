import types,inspect
from storage import VideoDatabase

class ColumnIndexException(Exception):
     def __init__(self, indexes):
         self.str = "Duplicate column indexes: " + repr(indexes)
     def __str__(self):
         return self.str
     
class ColumnNameException(Exception):
     def __init__(self, names):
         self.str = "Duplicate column names: " + repr(names)
     def __str__(self):
         return self.str

class ColumnTypeException(Exception):
     def __init__(self, value):
         self.value = "Unable to map: " + repr(type(value)) + " to a SQLite type"
     def __str__(self):
         return repr(self.value)

class Column(object):
    def __init__(self, value, name, index = 0, db_value_fn=lambda col: col.value):
        try:
            self.sqlite_type = { type(''): 'TEXT', type(1): 'INTEGER', type(1.0): 'REAL'}[type(value)]
        except:
            if value is not None:
                raise ColumnTypeException(value)
        self.value = value
        self.index = index
        self.name = name
        self.db_value_fn = db_value_fn
        
    def __str__(self):
        return "Column[name=" + repr(self.name) + ", index=" + repr(self.index) + ", value=" + repr(self.value) + "]"
    def __repr__(self):
        return self.__str__()
    def __getattr__(self, name):
        if name == 'db_value':
            return self.db_value_fn(self)
        raise AttributeError()
    
    @classmethod
    def ID(cls):
        return Column(-1, "id", 0, lambda col: (None if col.value == -1 else col.value))
    
    @classmethod
    def copy(cls, column, copy_value = False):
        try:
            return column.__copy__(copy_value)
        except:
            if copy_value:
                col = Column(column.value, column.index, column.name, column.db_value_fn)
            else:
                col = Column(None, column.index, column.name, column.db_value_fn)
            col.sqlite_type = column.sqlite_type
            return col

class TextColumn(Column):
    def __init__(self, name):
        Column.__init__(self, '', name)
class IntegerColumn(Column):
    def __init__(self, name):
        Column.__init__(self, 0, name)
class RealColumn(Column):
    def __init__(self, name):
        Column.__init__(self, 0.0, name)
class RefrenceColumn(Column):
    def __init__(self, name, type, db):
        Column.__init__(self, None, name, -1, lambda col: (None if col.value == None else col.value.id))
        self.sqlite_type = "INTEGER REFERENCES {0}(id) ON UPDATE CASCADE ON DELETE CASCADE".format(type.__table__)
        self.type = type
        self.db = db
    
    def __setattr__(self, name, value):
        if name != 'value' or value == None:
            super(Column, self).__setattr__(name, value)
        elif type(value) == self.type:
            super(Column, self).__setattr__(name, value)
        else:
            value = self.type.selectby_id(value, self.db)
            super(Column, self).__setattr__(name, value)
    
    def __str__(self):
        return "RefrenceColumn[name=" + repr(self.name) + ", index=" + repr(self.index) + ", value=" + repr(self.value) + ", type=" + repr(self.type) + "]"
    def __repr__(self):
        return self.__str__()
    
    def __copy__(self, copy_value = False):
        try:
            col = RefrenceColumn(self.name, self.type, self.db)
            col.index = self.index
            if copy_value:
                col.value = self.value
            return col
        except Exception, e:
            print "WTF: " + repr(e)
            traceback.print_exc()

def db_field_access(name):
    return name + "__db"
def is_db_field_access(name):
    return name.endswith("__db")

def define_columns(type, columns):
    def decompose_index():
        return reduce(
            lambda (u, d), o : (u.union([o.index]), d.union(u.intersection([o.index]))),
            columns,
            (set(), set()))
    def decompose_name():
        return reduce(
            lambda (u, d), o : (u.union([o.name]), d.union(u.intersection([o.name]))),
            columns,
            (set(), set()))

    for idx,column in enumerate(columns):
        column.index = idx
                
    (_, dup_index) = decompose_index()
    if dup_index: 
        raise ColumnIndexException(dup_index)
    (_, dup_name) = decompose_name()
    if dup_name: 
        raise ColumnNameException(dup_name)
    
    type.fields = ["__"+column.name for column in columns]
    type.fields_init = dict(("__"+column.name,column.index) for column in columns)
    
def define_sql_statements(type, name, columns):    
    def values():
        for index,column in enumerate(columns):
            if index == 0:
                vals = "("
            elif index == len(columns) - 1:
                vals += column.name + ")"
            else:
                vals += column.name + ', '
        return vals
    
    def sql_for_column(column, index):
        if 'TEXT' == column.sqlite_type:
            return "'{" + str(index) + "}'"
        else:
            return "{" + str(index) + "}"
    
    drop_table_sql = "DROP TABLE IF EXISTS '{0}'".format(name)
    insert_into_sql = "INSERT INTO '{0}'{1} VALUES({2})".format(name, values(), ','.join('?' * (len(columns) - 1)))
    insert_multiple_sql = "INSERT INTO '{0}' VALUES({1})".format(name, ','.join('?' * len(columns)))
    select_all_sql = "SELECT * FROM '{0}'".format(name)
    select_by_id_sql = "SELECT * FROM {0} WHERE id=".format(name) + "{0};"
    update_sql = "UPDATE '{0}' SET ".format(name)
    
    for index,column in enumerate(columns):
        if index == 0:
            create_table_sql = "CREATE TABLE IF NOT EXISTS '" + name + "'(" + column.name + " INTEGER PRIMARY KEY, "
        elif index == len(columns) - 1:
            create_table_sql += column.name + ' ' + column.sqlite_type + ')'
            update_sql += "{0}=:{0} WHERE id=:id".format(column.name)
        else:
            create_table_sql += column.name + ' ' + column.sqlite_type + ', '
            update_sql += "{0}=:{0}, ".format(column.name)
            
    def drop_table(cls, db):
        print "DROPPING TABLE: " + drop_table_sql
        db.cur().execute(drop_table_sql)
    def create_table(cls, db):
        print "CREATING TABLE: " + create_table_sql
        db.cur().execute(create_table_sql)
    def insert_multiple(cls, db, entities):
        many = tuple(entity.__tuple__() for entity in entities)
        print "INSERTING MULTIPLE: " + insert_multiple_sql + " Entities: " + repr(many)
        return db.executemany(insert_multiple_sql, many)
    def insert_into(cls, entity, db):
        print insert_into_sql
        db.execute(insert_into_sql, tuple([getattr(entity, db_field_access(column.name)) for column in columns[1:]]))
    def select_all(cls, db):
        print "SELECTING ALL: " + select_all_sql
        cur = db.execute(select_all_sql)
        
        entities = []
        for row in cur.fetchall():
            print "Row: " + repr(row)
            entities.append(cls.__from_row__(row))
        return entities
    def selectby_id(cls, id, db):
        sql = select_by_id_sql.format(id)
        print sql
        return db.execute(sql, None, lambda cur: cls.__from_row__(cur.fetchone()))
    def update_row(cls, entity, db):
        if entity.id:
            print update_sql
            db.execute(update_sql, dict([(column.name, getattr(entity, db_field_access(column.name))) for column in columns]))
        else:
            cls.insert_into(entity, db)
            
    type.drop_table = types.MethodType(drop_table, type) 
    type.create_table = types.MethodType(create_table, type) 
    type.insert_into = types.MethodType(insert_into, type)
    type.insert_multiple = types.MethodType(insert_multiple, type)
    type.select_all = types.MethodType(select_all, type)
    type.selectby_id = types.MethodType(selectby_id, type)
    type.update_row = types.MethodType(update_row, type)
    
def define_instance_methods(type, name):
    def __tuple__(self):
        return tuple(getattr(self, field).db_value for field in type.fields)
    def insert(self, db):
        pass
    
    def __str__(self):
        str = name + "["
        endIdx = len(type.fields) - 1
        for idx,field in enumerate(type.fields):
            if idx == endIdx:
                str += field[2:] + '=' + repr(getattr(self, field).value) + ']'
            else:
                str += field[2:] + '=' + repr(getattr(self, field).value) + ', '
        return str
    def __from_row__(cls, row):
        if row:
            entity = type()
            for idx,col in enumerate(row):
                getattr(entity, type.fields[idx]).value = col
            return entity
        return None
    
    type.__tuple__ = __tuple__
    type.__str__ = __str__
    type.__repr__ = __str__
    type.__from_row__ = types.MethodType(__from_row__, type)

def define_column_access(type):
    def __getattr__(self, name):
        if (is_db_field_access(name)):
            pvtname = "__" + name[:-4]
            if pvtname in type.fields:
                return getattr(self, pvtname).db_value
        else:
            pvtname = "__" + name
            if pvtname in type.fields:
                return getattr(self, pvtname).value
        raise AttributeError()
    def __setattr__(self, name, value):
        pvtname = "__" + name
        if pvtname in type.fields:
            getattr(self, pvtname).value = value
        else:
            super(type, self).__setattr__(name, value)
    
    type.__getattr__ = __getattr__
    type.__setattr__ = __setattr__

class EntityMeta(type):        
    def __new__(cls, name, bases, attrs):
        newtype = super(EntityMeta, cls).__new__(cls, name, bases, attrs)
        newtype.__table__ = name
        
        try:
            columns = attrs['__columns__']
            columns.insert(0, Column.ID())
        except:
            print "This is a base class, not processing"
            newtype.fields = [];
            return newtype
        
        define_columns(newtype, columns)
        define_sql_statements(newtype, name, columns)
        define_instance_methods(newtype, name)
        define_column_access(newtype)
        
        return newtype
    
    def __init__(self, name, bases, attrs):
        super(EntityMeta, self).__init__(name, bases, attrs)

    def __call__(cls, *args, **kwds):
        instance = type.__call__(cls, *args, **kwds)
        for field in cls.fields:
            setattr(instance, field, Column.copy(cls.__columns__[cls.fields_init[field]]))        
        return instance
            
class BaseEntity(object):
    __metaclass__ = EntityMeta
    
class CloudServer(BaseEntity):
    __columns__ = [TextColumn('ip_address'), IntegerColumn('port'), TextColumn('server_id')]
    
    @classmethod
    def new(cls, ip_address = '', port = -1, server_id = ''):
        cs = CloudServer()
        cs.ip_address = ip_address
        cs.port = int(port)
        cs.server_id = server_id
        return cs
    
    @classmethod
    def selectby_server_id(cls, id, db = VideoDatabase):
        sql = "SELECT * FROM {0} WHERE server_id=?;".format(cls.__table__)
        print sql
        return db.execute(sql, (id, ), lambda cur: cls.__from_row__(cur.fetchone()))
        
        
class Video(BaseEntity):
    __columns__ = [TextColumn('name'), TextColumn('description'), TextColumn('stream'), TextColumn('cover'), RefrenceColumn('server', CloudServer, VideoDatabase)]
    
    @classmethod
    def selectby_name(cls, name, db = VideoDatabase):
        sql = "SELECT * FROM {0} WHERE name=?;".format(cls.__table__)
        print sql
        return db.execute(sql, (name, ), lambda cur: cls.__from_row__(cur.fetchone()))
