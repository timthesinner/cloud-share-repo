import xbmc, xbmcaddon, xbmcplugin, xbmcgui
import sys,time,threading
import select, socket, struct
import json
import sys, traceback
import urllib

from cloudshare.common.storage import VideoDatabase
from cloudshare.common.entity import *
from cloudshare.common.net import RestClient, HttpResponse

VideoDatabase.create_table(Video)
VideoDatabase.create_table(CloudServer)  

class InterruptableThread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.event = threading.Event()
        self.event.clear()
    
    def sleep(self, timeout=None):
        self.event.wait(timeout)
        
    def interrupt(self):
        self.event.set()
        self.event.clear()

class UdpDiscovery(InterruptableThread):
    def __init__(self):
        InterruptableThread.__init__(self)
        self.setDaemon(True)
        self.start()
        
    def stop(self):
        if (self.socket):
            try:
                self.socket.close()
            except:
                pass
    
    def interrupt(self):
        self.stop()
        super(UdpDiscovery, self).interrupt()
        
    def run(self):
        print "Starting: " + repr(self)
        MCAST_GRP = "239.192.73.73"
        MCAST_PORT = 56984
        
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        except AttributeError:
            pass # Some systems don't support SO_REUSEPORT
        
        try:
            #First bind the socket to the group port
            self.socket.bind(('', MCAST_PORT))
            
            # Tell the operating system to add the socket to the multicast group on all interfaces.
            group = socket.inet_aton(MCAST_GRP)
            mreq = struct.pack('4sL', group, socket.INADDR_ANY)
            self.socket.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            
            while (not xbmc.abortRequested):
                print "Waiting for announce"
                data, address = self.socket.recvfrom(1024)
                try:
                    server = json.loads(data)
                    serverId = server['serverId']
                    port = server['port']
                    
                    with VideoDatabase as db:
                        serverEntry = CloudServer.selectby_server_id(serverId, db)
                        if serverEntry:
                            serverEntry.ip_address = str(address[0])
                            serverEntry.port = port
                        else:
                            serverEntry = CloudServer.new(address[0], port, serverId)
                        CloudServer.update_row(serverEntry, db)
                except:
                    print "HAd an error"
                    traceback.print_exc()
        finally:
            self.stop()
            
class LibraryDiscovery(InterruptableThread):
    def __init__(self):
        InterruptableThread.__init__(self)
        self.setDaemon(True)
        self.start()
    
    def remove_avi(self, name):
        if name.endswith('.avi'):
            return name[:-4]
        return name
    
    def run(self):
        print "Starting: " + repr(self)
        try:
            while (not xbmc.abortRequested):
                processed = False
                with VideoDatabase as db:
                    servers = CloudServer.select_all(db)
                    if len(servers) == 0:
                        print "No Cloud Streaming Servers have been detected"
                    else:
                        processed = True
                        for server in servers:
                            req_url = "http://{0}:{1}/rest/library/".format(server.ip_address, server.port)
                            
                            response = RestClient().fetch(req_url)
                            if response:
                                full_library = json.loads(response.content)
                            else:
                                print "Server response was empty"
                                full_library = []
                             
                            media_entries = []   
                            for key in full_library:
                                lib = full_library[key]
                                try:
                                    media = lib['media']
                                    if (media):
                                        media_entries.extend(media)
                                except:
                                    pass
                                
                            for media in media_entries:
                                try:
                                    if media['type'] == 'Movie':
                                        name = media['fileName']
                                        video = Video.selectby_name(name)
                                        if video is None:
                                            video = Video()
                                            video.name = name
                                            #HTTP Based clients need the .avi to trigger the server to stream DIVX style
                                            video.stream = urllib.quote(self.remove_avi(media['streamUri']))
                                            video.server = server
                                            Video.update_row(video, db)
                                except Exception:
                                    exc_type, exc_value, exc_traceback = sys.exc_info()
                                    lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
                                    print 'Encountered Exception\n'.join(line for line in lines)
                #END WITH VideoDatabase as db:
                
                if (processed):
                    self.sleep(60*10)
                else:
                    self.sleep(5)
        except Exception, e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
            print 'Encountered Exception\n'.join(line for line in lines)
        except:
            print "UNKNOWN ERROR"
            
class CloudServerWrapper:
    @classmethod
    def start(cls):
        udp_disco = UdpDiscovery()
        library_disco = LibraryDiscovery()
        try:
            while (not xbmc.abortRequested):
                time.sleep(1)
            print "Shutting down Cloud Streaming Service"
        finally:
            #Force the socket to close
            udp_disco.interrupt()
            library_disco.interrupt()

#try:
#    vid = Video()
#    vid.name = "Blah"
#    Video.insert_multiple(VideoDatabase, [vid])
#    
#    print "Video Database: " + repr(Video.select_all(VideoDatabase))
#    
#    VideoDatabase.commit()
#except Exception, e:
#    print "Crap got an exception: " + repr(e)
#    VideoDatabase.rollback()
#    raise Exception(e)
#finally:
#    VideoDatabase.close()
