import xbmcaddon
import sys,os,time

__addon__ = xbmcaddon.Addon(id= sys.argv[0][9:-1])

sys.path.insert(0, os.path.join(__addon__.getAddonInfo('path'), 'lib'))
from cloudshare.coreserver import CloudServerWrapper
CloudServerWrapper.start()
